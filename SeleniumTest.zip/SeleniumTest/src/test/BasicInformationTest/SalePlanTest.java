package test.BasicInformationTest;

public class SalePlanTest {
}
