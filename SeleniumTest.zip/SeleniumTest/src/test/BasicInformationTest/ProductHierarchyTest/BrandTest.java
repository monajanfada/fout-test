package test.BasicInformationTest.ProductHierarchyTest;

import org.openqa.selenium.WebElement;
import test.BaseTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class BrandTest extends BaseTest {

   // public static final String ADMIN_USERNAME = "admin";
    // public static final String ADMIN_PASSWORD = "admin";

    @Override
    public void internalTest() {
        login();
        saveBrand();
        searchBrand();
        editBrand();
        searchEditedBrand();
        deleteBrand();
    }

    public void saveBrand() {

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

        // Opening Basic Information module
        click("mnu-200");

        // Opening Product Hierarchy
        click("mnu-240");

        // Opening Brand
        click("mnu-242");

        // Creating new Brand
        click("newItem");

        // Filling the boxes
        type("englishName", "absc");
        String englishName = getText("englishName");
        type("name", "یبیل");
        String name = getText("name");
        System.out.println("englishName: " + englishName);
        System.out.println("name:" + name);
//        String persianWord ="\\u0633\\u0644\\u0627\\u0645";

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        // Saving Brand
        click("submitBrand");
    }

    public void searchBrand() {
        // Opening Basic Information module
        click("mnu-200");

        // Opening Product Hierarchy
        click("mnu-240");

        // Opening Brand
        click("mnu-241");

        List<WebElement> childElementByClass = getSearchTableHeaderElements();
        if(childElementByClass != null && childElementByClass.size() > 0){
            type(childElementByClass.get(0),"یبیل");
            type(childElementByClass.get(1),"absc");
        }

    }

    public void editBrand() {
        // Write codes for edit Brand
    }

    public void searchEditedBrand() {
        // Write codes for searchEdited Brand
    }

    public void deleteBrand() {
        // Write codes for delete Brand
    }
}
