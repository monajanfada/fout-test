package test.BasicInformationTest.CountryDivisionTest;

public class CityRegionTest {
}
