package test.BasicInformationTest;

public class InventoryTest {
}
