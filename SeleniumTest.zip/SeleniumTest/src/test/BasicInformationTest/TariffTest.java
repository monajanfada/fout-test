package test.BasicInformationTest;

import org.openqa.selenium.WebElement;
import test.BaseTest;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class TariffTest extends BaseTest {

    @Override
    public void internalTest() {
        login();
        saveTariff();
        searchTariff();
        editTariff();
        searchEditedTariff();
        deleteTariff();
    }

    public void saveTariff() {

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        // Opening Basic Information module
        click("mnu-200");

        // Opening Tariff
        click("mnu-260");

        waitForPageToLoad();
        //webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        WebElement newItem = findElementById("newItem");
        System.out.println(newItem != null ? "exist" : "null");
        // Creating new Tariff
        click("newItem");

        // Filling the boxes
        type("name", "نرخنامه اول");
        String name = getText("name");
        System.out.println("name:" + name);

        click("asynchronous");

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        // Saving Tariff
        click("submitTariff");
    }

    public void searchTariff() {
        // Opening Basic Information module
        click("mnu-200");

        // Opening Product Hierarchy
        click("mnu-240");

        // Opening Tariff
        click("mnu-241");

        List<WebElement> childElementByClass = getSearchTableHeaderElements();
        if(childElementByClass != null && childElementByClass.size() > 0){
            type(childElementByClass.get(0),"یبیل");
            type(childElementByClass.get(1),"absc");
        }

    }

    public void editTariff() {
        // Write codes for edit Tariff
    }

    public void searchEditedTariff() {
        // Write codes for searchEdited Tariff
    }

    public void deleteTariff() {
        // Write codes for delete Tariff
    }
}
