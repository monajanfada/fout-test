//package ProductHierarchyTest;
//
//import java.util.concurrent.TimeUnit;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//public class BrandTest extends BaseFoutTest {
//    public static WebDriver driver = null;
//
//
//        public static final String ADMIN_USERNAME = "admin";
//        public static final String ADMIN_PASSWORD = "admin";
//
//        //@Override
//        public void internalTest() {
//            loginAndOpenForm("LoginPage", ADMIN_USERNAME, ADMIN_PASSWORD);
//            saveBrand();
//            searchBrand();
//            editBrand();
//            searchEditedBrand();
//            deleteBrand();
//        }
//
//        public void saveBrand() {
//
//                // Opening Basic Information module
//                driver.findElement(By.id("mnu-200")).click();
//
//                // Opening Product Hierarchy
//                driver.findElement(By.id("mnu-240")).click();
//
//                // Opening Brand
//                driver.findElement(By.id("mnu-242")).click();
//
//                // Creating new Company
//                driver.findElement(By.id("newItem")).click();
//
//                // Filling the boxes
//                WebElement englishName = driver.findElement(By.id("englishName"));
//                englishName.sendKeys("absc");
//                WebElement name = driver.findElement(By.id("name"));
////        String persianWord ="\\u0633\\u0644\\u0627\\u0645";
//                String persianWord ="یبیل";
//                name.sendKeys(persianWord);
//
//                // Saving company
//                driver.findElement(By.id("submitCompany")).click();
//            }
//
//            public void searchBrand() {
//                // Write codes for search Company
//            }
//
//            public void editBrand() {
//                // Write codes for edit Company
//            }
//
//            public void searchEditedBrand() {
//                // Write codes for searchEdited Company
//            }
//
//            public void deleteBrand() {
//                // Write codes for delete Company
//                // closing the browser
//                //driver.close();
//            }
//
//        }
//
//
////        //dashboard
////        driver.findElement(By.id("submitButton")).click();
//
//        // Opening Basic Information module
//        driver.findElement(By.id("mnu-200")).click();
//
//        // Opening Product Hierarchy
////        driver.findElement(By.id("mnu-280")).click();
//        driver.findElement(By.id("mnu-240")).click();
//
//        // Opening Company
////        driver.findElement(By.id("mnu-282")).click();
//        driver.findElement(By.id("mnu-241")).click();
//
//        // Creating new Company
//        driver.findElement(By.id("newItem")).click();
//
//        // Filling the boxes
//        //WebElement englishName = driver.findElement(By.id("englishName"));
//        //englishName.sendKeys("absc");
//        WebElement name = driver.findElement(By.id("name"));
////        String persianWord ="\\u0633\\u0644\\u0627\\u0645";
//        String persianWord ="یبیل";
//        name.sendKeys(persianWord);
//
//
//
//
//
//    }
//}
