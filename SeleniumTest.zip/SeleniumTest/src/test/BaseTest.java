package test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

public abstract class BaseTest /*implements TestConstants*/ {

    public static final String BASE_URL = "http://panel.lafa.me/";
    public static final String TMP_DIR = System.getProperty("java.io.tmpdir");

    protected Integer maxWaitDurationSeconds = 20;
    protected WebDriver webDriver;
    protected WebDriverWait webDriverWait;

    public abstract void internalTest() throws Exception;

    @Before
    public void startup() {
        // Initiating your chromedriver
        //String browser = System.getProperty("browser");
        String browser = "firefox";
        if ("firefox".equalsIgnoreCase(browser)) {
            testInFirefox();
        } else {
            testInChrome();
        }
}

    private void testInFirefox() {
        System.setProperty("webdriver.chrome.driver",
                "..\\..\\..\\selenium\\selenium\\driver\\geckodriver-v0.27.0-win64.exe");
        FirefoxOptions firefoxOptions = new FirefoxOptions();
        //firefoxOptions.setProfile(getFirefoxProfile());
        webDriver = new FirefoxDriver(firefoxOptions);
        afterDriverInitialized();
    }

    private void testInChrome() {
        System.setProperty("webdriver.chrome.driver",
                "..\\..\\..\\selenium\\selenium\\driver\\chromedriver.exe");
//        System.setProperty("webdriver.chrome.driver", "D:\\selenium\\selenium\\driver\\chromedriver.exe");
//        webDriver = new ChromeDriver();
        String chromeProfile = TMP_DIR;
        ArrayList<String> switches = new ArrayList<>();
        switches.add("--user-data-dir=" + chromeProfile);
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--ignore-certificate-errors");
        chromeOptions.setCapability("chrome.switches", switches);
        webDriver = new ChromeDriver(chromeOptions);
        afterDriverInitialized();
    }

    private void afterDriverInitialized(){
        webDriverWait = new WebDriverWait(webDriver,maxWaitDurationSeconds);
    }

    @Test
    public void test() throws Exception {
        // Creating WebDriver instance and all setting come here.
        try {
            internalTest();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           // webDriver.close();
        }
    }

    @After
    public void tearDown() {
        if (webDriver != null) {
            //webDriver.quit();
        }
        System.out.println("Execution of '" + getClass().getSimpleName() + "' finished.");
    }

    protected void navigateTo(String url) {
        webDriver.navigate().to(BASE_URL + url);
        waitForPageToLoad();
    }

   // public static final String ADMIN_USERNAME = "admin";
   // public static final String ADMIN_PASSWORD = "admin";

    public void login() {
        navigateTo("login");
        type("userName", "admin");
        type("password", "admin");
        click("submitButton");
        webDriver.manage().window().maximize();
    }

    public void type(String id, String value) {
        type(findElementById(id),value);
    }

    public void type(WebElement webElement, String value) {
        webElement.sendKeys(value);
    }

    public WebElement findElementById(String id) {
        return waitForPresenceOfElement(id);
        //return webDriver.findElement(By.id(id));
    }

    public WebElement findElementByClass(String className) {
        WebElement element = webDriver.findElement(By.className(className));
        return element;
    }

    public void click(String id) {
        //findElementById(id).click();
        WebElement webElement = webDriverWait.until(ExpectedConditions.elementToBeClickable(By.id(id)));
        webElement.click();
    }

    public String getValue(String id) {
        return findElementById(id).getAttribute("value");
    }

    public String getText(String id) {
        return findElementById(id).getText();
    }

    public String getText(WebElement webElement) {
        return webElement != null ? webElement.getText() : "";
    }

    public List<WebElement> getChildElementById(String parentId) {
        return parentId != null ? webDriver.findElements(By.id(parentId)) : new ArrayList<>();
    }

    public List<WebElement> getChildElementByClass(String parentClass) {
        return parentClass != null ? webDriver.findElements(By.className(parentClass)) : new ArrayList<>();
    }

    public List<WebElement> getSearchTableHeaderElements() {
        String dataTableClass = "MuiTableBody-root";
        WebElement parentElement = findElementByClass(dataTableClass);
        List<WebElement> tableRowElements = parentElement != null ? parentElement.findElements(By.xpath("*")) : new ArrayList<>();
        if(tableRowElements != null && tableRowElements.size() > 0){
            WebElement headerRow = tableRowElements.get(0);
            List<WebElement> elements = headerRow.findElements(By.tagName("input"));
            return elements;
        }
        return new ArrayList<>();
    }

    public List<WebElement> getSearchTableFirstRow(){
        String dataTableClass = "MuiTableBody-root";
        WebElement parentElement = findElementByClass(dataTableClass);
        List<WebElement> tableRowElements = parentElement != null ? parentElement.findElements(By.xpath("*")) : new ArrayList<>();
        if(tableRowElements != null && tableRowElements.size() > 0){
            WebElement firstRow = tableRowElements.get(1);
            List<WebElement> elements = firstRow.findElements(By.tagName("td"));
            return elements;
        }
        return new ArrayList<>();
    }

    public void waitForFixedDuration(int milliseconds){
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    protected void waitForPageToLoad(){
        webDriverWait.until(ExpectedConditions.jsReturnsValue("return document.readyState=='complete';"));
        waitForFixedDuration(1000);
    }

    public WebElement waitForPresenceOfElement(String id){
        WebElement webElement = webDriverWait.until(ExpectedConditions.presenceOfElementLocated(By.id(id)));
        System.out.println(webElement != null ? "Element with id "+id+" is found." : "Element with id "+id+" not found.");
        return webElement;
    }

    public WebElement waitForVisibilityOfElement(String id){
        return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));
    }

    public void menueClick(){
         click("mnu-200");

    }

    public void checkText(String id, String text){
        String targetText = getText(id);
        if(text != null && text.length() > 0){
            return;
        }
       assertEquals(text, targetText);
    }

    public void checkText(WebElement webElement, String text){
        String targetText = getText(webElement);
        if(text != null && text.length() > 0){
            return;
        }
        assertEquals(text, targetText);
    }

}
