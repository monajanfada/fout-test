package test.BasicInformationTest.ProductHierarchyTest;

import org.openqa.selenium.WebElement;
import test.BaseTest;
import java.sql.Driver;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CompanyTest extends BaseTest {
    
    private static final String FARSI_NAME_CREATE = "شرکت پرگاس طب";
    private static final String ENGLISH_NAME_CREATE = "pergas teb company";
    private static final String FARSI_NAME_EDIT = "شرکت ویرایش شده";
    private static final String ENGLISH_NAME_EDIT = "Edited company";


    @Override
    public void internalTest() {
        login();
        saveCompany();
        searchCompany(FARSI_NAME_CREATE,ENGLISH_NAME_CREATE);
        editCompany();
        searchCompany(FARSI_NAME_EDIT,ENGLISH_NAME_EDIT);
        deleteCompany();
        searchCompany(FARSI_NAME_EDIT,ENGLISH_NAME_EDIT);
    }


    public void searchCompany(String farsiName, String englishName) {

        List<WebElement> childElementByClass = getSearchTableHeaderElements();
        if(childElementByClass != null && childElementByClass.size() > 0){
            type(childElementByClass.get(0),farsiName);
            type(childElementByClass.get(1),englishName);
        }
        List<WebElement> searchTableFirstRow = getSearchTableFirstRow();
        checkText(searchTableFirstRow.get(0),farsiName);
        checkText(searchTableFirstRow.get(1),englishName);
    }


    public void saveCompany() {

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        click("mnu-200");

        // Opening Product Hierarchy
        click("mnu-240");

        // Opening Company
        click("mnu-241");
        waitForPageToLoad();
        // Creating new Company
        click("newItem");

        // Filling the boxes
        type("englishName", ENGLISH_NAME_CREATE);
        String englishName = getText("englishName");
        type("name", FARSI_NAME_CREATE);
        String name = getText("name");
        System.out.println("englishName: " + englishName);
        System.out.println("name:" + name);

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        // Saving company
        click("submitCompany");

    }


    public void editCompany() {

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        click("mnu-200");

        // Opening Product Hierarchy
        click("mnu-240");

        // Opening Company
        click("mnu-241");
        waitForPageToLoad();

        // Editing Company
        click("edit-134905");

        // Clearing the box
        findElementById("name").clear();
        findElementById("englishName").clear();

        // Filling tje boxes
        type("name", FARSI_NAME_EDIT);
        type("englishName", ENGLISH_NAME_EDIT);

        // Saving edited company
        click("submitCompany");

    }


    public void deleteCompany() {

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        click("mnu-200");

        // Opening Product Hierarchy
        click("mnu-240");

        // Opening Company
        click("mnu-241");
        waitForPageToLoad();

        // Deleting Company
        click("remove-134905");

    }

}
