package test.BasicInformationTest.SaleDivisionTest;
import test.BaseTest;

import java.util.concurrent.TimeUnit;

public class InternationalTerritoryTest extends BaseTest {


    private static final String FARSI_NAME = "منطقه بین المللی خاورمیانه";
    private static final String ENGLISH_NAME = "middle east";

    @Override
    public void internalTest() {
        login();
        saveInternationalTerritory();
        searchInternationalTerritory();
        editInternationalTerritory();
        searchEditedInternationalTerritory();
        deleteInternationalTerritory();
    }


    public void saveInternationalTerritory() {

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

        // Opening Basic Information module
        click("mnu-200");

        // Opening Product Hierarchy
        click("mnu-280");

        // Opening InternationalTerritory
        click("mnu-282");

        // Creating new InternationalTerritory
        click("newItem");

        // Filling the boxes
        type("name", FARSI_NAME);
        String name = getText("name");
        System.out.println("name:" + name);
//        String persianWord ="\\u0633\\u0644\\u0627\\u0645";

        // Applied wait time
        webDriver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

        // Saving InternationalTerritory
        click("submitInternationalTerritory");
    }

    public void searchInternationalTerritory() {
        // Write codes for search InternationalTerritory
    }

    public void editInternationalTerritory() {
        // Write codes for edit InternationalTerritory
    }

    public void searchEditedInternationalTerritory() {
        // Write codes for searchEdited InternationalTerritory
    }

    public void deleteInternationalTerritory() {
        // Write codes for delete InternationalTerritory
    }
}


