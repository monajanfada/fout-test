package test.BasicInformationTest.CountryDivisionTest;

public class ProvinceTest {
}
