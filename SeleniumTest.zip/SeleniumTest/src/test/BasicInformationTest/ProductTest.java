package test.BasicInformationTest;

public class ProductTest {
}
